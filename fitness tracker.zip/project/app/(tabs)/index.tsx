import React from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFitnessData } from '@/hooks/useFitnessData';
import { MetricCard } from '@/components/MetricCard';
import { StatCard } from '@/components/StatCard';
import { Footprints, Route, Flame, Clock, TrendingUp, Award } from 'lucide-react-native';

export default function Dashboard() {
  const { currentActivity, userProfile, isTracking } = useFitnessData();
  const [refreshing, setRefreshing] = React.useState(false);

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    // Simulate refresh
    setTimeout(() => setRefreshing(false), 1000);
  }, []);

  const formatDistance = (meters: number): string => {
    if (meters >= 1000) {
      return (meters / 1000).toFixed(1);
    }
    return meters.toString();
  };

  const getDistanceUnit = (meters: number): string => {
    return meters >= 1000 ? 'km' : 'm';
  };

  const getCurrentDate = (): string => {
    return new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const stepProgress = Math.min(currentActivity.steps / userProfile.dailyStepGoal, 1);
  const distanceProgress = Math.min(currentActivity.distance / userProfile.dailyDistanceGoal, 1);
  const calorieProgress = Math.min(currentActivity.calories / userProfile.dailyCalorieGoal, 1);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.greeting}>Hello, {userProfile.name}!</Text>
          <Text style={styles.date}>{getCurrentDate()}</Text>
          <View style={styles.trackingStatus}>
            <View style={[styles.trackingDot, { backgroundColor: isTracking ? '#10B981' : '#EF4444' }]} />
            <Text style={styles.trackingText}>
              {isTracking ? 'Tracking Active' : 'Tracking Inactive'}
            </Text>
          </View>
        </View>

        {/* Main Metrics */}
        <View style={styles.metricsGrid}>
          <MetricCard
            title="Steps"
            value={currentActivity.steps.toLocaleString()}
            unit="steps"
            progress={stepProgress}
            goal={userProfile.dailyStepGoal.toLocaleString()}
            colors={['#3B82F6', '#1E40AF']}
            icon={<Footprints size={24} color="#FFFFFF" />}
          />
          
          <MetricCard
            title="Distance"
            value={formatDistance(currentActivity.distance)}
            unit={getDistanceUnit(currentActivity.distance)}
            progress={distanceProgress}
            goal={`${formatDistance(userProfile.dailyDistanceGoal)} ${getDistanceUnit(userProfile.dailyDistanceGoal)}`}
            colors={['#10B981', '#059669']}
            icon={<Route size={24} color="#FFFFFF" />}
          />
        </View>

        <View style={styles.metricsGrid}>
          <MetricCard
            title="Calories"
            value={currentActivity.calories.toString()}
            unit="kcal"
            progress={calorieProgress}
            goal={userProfile.dailyCalorieGoal.toString()}
            colors={['#F59E0B', '#D97706']}
            icon={<Flame size={24} color="#FFFFFF" />}
          />
          
          <MetricCard
            title="Active Time"
            value={currentActivity.activeMinutes.toString()}
            unit="minutes"
            progress={Math.min(currentActivity.activeMinutes / 60, 1)}
            goal="60"
            colors={['#8B5CF6', '#7C3AED']}
            icon={<Clock size={24} color="#FFFFFF" />}
          />
        </View>

        {/* Quick Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Today's Summary</Text>
          <View style={styles.statsRow}>
            <StatCard
              title="Avg. Pace"
              value={currentActivity.steps > 0 ? `${Math.round(currentActivity.activeMinutes / (currentActivity.steps / 1000))}` : '0'}
              subtitle="steps/min"
              color="#3B82F6"
              icon={<TrendingUp size={20} color="#3B82F6" />}
            />
            <StatCard
              title="Achievement"
              value={`${Math.max(stepProgress, distanceProgress, calorieProgress) > 0.5 ? '🏆' : '🎯'}`}
              subtitle={`${Math.round(Math.max(stepProgress, distanceProgress, calorieProgress) * 100)}% best goal`}
              color="#10B981"
              icon={<Award size={20} color="#10B981" />}
            />
          </View>
        </View>

        {/* Motivational Section */}
        <View style={styles.motivationCard}>
          <Text style={styles.motivationTitle}>
            {stepProgress >= 1 ? '🎉 Goal Achieved!' : '💪 Keep Going!'}
          </Text>
          <Text style={styles.motivationText}>
            {stepProgress >= 1
              ? `Amazing! You've reached your daily step goal of ${userProfile.dailyStepGoal.toLocaleString()} steps!`
              : `You're ${Math.round((1 - stepProgress) * userProfile.dailyStepGoal).toLocaleString()} steps away from your goal!`}
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingBottom: 20,
  },
  header: {
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  greeting: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  date: {
    fontSize: 16,
    color: '#6B7280',
    marginBottom: 12,
  },
  trackingStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  trackingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  trackingText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#374151',
  },
  metricsGrid: {
    flexDirection: 'row',
    paddingHorizontal: 12,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  motivationCard: {
    backgroundColor: '#FFFFFF',
    margin: 20,
    padding: 20,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  motivationTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  motivationText: {
    fontSize: 16,
    color: '#6B7280',
    lineHeight: 24,
  },
});