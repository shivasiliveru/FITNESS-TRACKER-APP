import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFitnessData } from '@/hooks/useFitnessData';
import { User, CreditCard as Edit3, Save, Settings, Info, Award, Activity } from 'lucide-react-native';

export default function Profile() {
  const { userProfile, updateUserProfile, currentActivity, historicalData } = useFitnessData();
  const [isEditing, setIsEditing] = useState(false);
  const [editedProfile, setEditedProfile] = useState(userProfile);

  const handleSave = async () => {
    try {
      await updateUserProfile(editedProfile);
      setIsEditing(false);
      Alert.alert('Success', 'Profile updated successfully!');
    } catch (error) {
      Alert.alert('Error', 'Failed to update profile. Please try again.');
    }
  };

  const handleCancel = () => {
    setEditedProfile(userProfile);
    setIsEditing(false);
  };

  // Calculate BMI
  const calculateBMI = () => {
    const heightInMeters = userProfile.height / 100;
    const bmi = userProfile.weight / (heightInMeters * heightInMeters);
    return bmi.toFixed(1);
  };

  // Calculate total achievements
  const getTotalStats = () => {
    const totalSteps = historicalData.reduce((sum, day) => sum + day.steps, 0) + currentActivity.steps;
    const totalDistance = historicalData.reduce((sum, day) => sum + day.distance, 0) + currentActivity.distance;
    const totalCalories = historicalData.reduce((sum, day) => sum + day.calories, 0) + currentActivity.calories;
    const daysTracked = historicalData.length + 1;
    
    return {
      totalSteps,
      totalDistance: Math.round(totalDistance / 1000 * 10) / 10, // Convert to km
      totalCalories,
      daysTracked,
    };
  };

  const stats = getTotalStats();
  const bmi = calculateBMI();

  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return { category: 'Underweight', color: '#3B82F6' };
    if (bmi < 25) return { category: 'Normal', color: '#10B981' };
    if (bmi < 30) return { category: 'Overweight', color: '#F59E0B' };
    return { category: 'Obese', color: '#EF4444' };
  };

  const bmiInfo = getBMICategory(parseFloat(bmi));

  const profileFields = [
    { label: 'Name', key: 'name', type: 'text' },
    { label: 'Age', key: 'age', type: 'numeric', unit: 'years' },
    { label: 'Weight', key: 'weight', type: 'numeric', unit: 'kg' },
    { label: 'Height', key: 'height', type: 'numeric', unit: 'cm' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerTop}>
            <View style={styles.avatarContainer}>
              <User size={32} color="#FFFFFF" />
            </View>
            <View style={styles.headerInfo}>
              <Text style={styles.name}>{userProfile.name}</Text>
              <Text style={styles.joinDate}>Member since January 2024</Text>
            </View>
          </View>
          
          <TouchableOpacity
            style={styles.editButton}
            onPress={isEditing ? handleSave : () => setIsEditing(true)}
          >
            {isEditing ? (
              <Save size={20} color="#FFFFFF" />
            ) : (
              <Edit3 size={20} color="#FFFFFF" />
            )}
            <Text style={styles.editButtonText}>
              {isEditing ? 'Save' : 'Edit Profile'}
            </Text>
          </TouchableOpacity>
          
          {isEditing && (
            <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Health Metrics */}
        <View style={styles.healthContainer}>
          <Text style={styles.sectionTitle}>Health Metrics</Text>
          <View style={styles.healthGrid}>
            <View style={styles.healthCard}>
              <Text style={styles.healthLabel}>BMI</Text>
              <Text style={[styles.healthValue, { color: bmiInfo.color }]}>{bmi}</Text>
              <Text style={[styles.healthCategory, { color: bmiInfo.color }]}>
                {bmiInfo.category}
              </Text>
            </View>
            <View style={styles.healthCard}>
              <Text style={styles.healthLabel}>Daily Calories</Text>
              <Text style={styles.healthValue}>{userProfile.dailyCalorieGoal}</Text>
              <Text style={styles.healthCategory}>Target</Text>
            </View>
          </View>
        </View>

        {/* Personal Information */}
        <View style={styles.personalContainer}>
          <Text style={styles.sectionTitle}>Personal Information</Text>
          <View style={styles.personalCard}>
            {profileFields.map((field) => (
              <View key={field.key} style={styles.fieldRow}>
                <Text style={styles.fieldLabel}>{field.label}</Text>
                {isEditing ? (
                  <View style={styles.fieldInputContainer}>
                    <TextInput
                      style={styles.fieldInput}
                      value={editedProfile[field.key as keyof typeof editedProfile].toString()}
                      onChangeText={(text) => {
                        const value = field.type === 'numeric' ? (parseInt(text) || 0) : text;
                        setEditedProfile(prev => ({
                          ...prev,
                          [field.key]: value,
                        }));
                      }}
                      keyboardType={field.type === 'numeric' ? 'numeric' : 'default'}
                      placeholder={`Enter ${field.label.toLowerCase()}`}
                    />
                    {field.unit && (
                      <Text style={styles.fieldUnit}>{field.unit}</Text>
                    )}
                  </View>
                ) : (
                  <Text style={styles.fieldValue}>
                    {userProfile[field.key as keyof typeof userProfile]} {field.unit || ''}
                  </Text>
                )}
              </View>
            ))}
          </View>
        </View>

        {/* Achievement Stats */}
        <View style={styles.achievementsContainer}>
          <Text style={styles.sectionTitle}>Your Achievements</Text>
          <View style={styles.achievementsGrid}>
            <View style={styles.achievementCard}>
              <Activity size={24} color="#3B82F6" />
              <Text style={styles.achievementValue}>{stats.totalSteps.toLocaleString()}</Text>
              <Text style={styles.achievementLabel}>Total Steps</Text>
            </View>
            <View style={styles.achievementCard}>
              <Award size={24} color="#10B981" />
              <Text style={styles.achievementValue}>{stats.totalDistance} km</Text>
              <Text style={styles.achievementLabel}>Distance Traveled</Text>
            </View>
            <View style={styles.achievementCard}>
              <Settings size={24} color="#F59E0B" />
              <Text style={styles.achievementValue}>{stats.totalCalories.toLocaleString()}</Text>
              <Text style={styles.achievementLabel}>Calories Burned</Text>
            </View>
            <View style={styles.achievementCard}>
              <Info size={24} color="#8B5CF6" />
              <Text style={styles.achievementValue}>{stats.daysTracked}</Text>
              <Text style={styles.achievementLabel}>Days Tracked</Text>
            </View>
          </View>
        </View>

        {/* App Information */}
        <View style={styles.appInfoContainer}>
          <Text style={styles.sectionTitle}>App Information</Text>
          <View style={styles.appInfoCard}>
            <View style={styles.appInfoRow}>
              <Text style={styles.appInfoLabel}>Version</Text>
              <Text style={styles.appInfoValue}>1.0.0</Text>
            </View>
            <View style={styles.appInfoRow}>
              <Text style={styles.appInfoLabel}>Data Storage</Text>
              <Text style={styles.appInfoValue}>Local Device</Text>
            </View>
            <View style={styles.appInfoRow}>
              <Text style={styles.appInfoLabel}>Tracking Status</Text>
              <View style={styles.statusContainer}>
                <View style={styles.statusDot} />
                <Text style={styles.appInfoValue}>Active</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Health Tips */}
        <View style={styles.tipsContainer}>
          <Text style={styles.sectionTitle}>Health Tips</Text>
          <View style={styles.tipsCard}>
            <Text style={styles.tipText}>
              💡 Aim for at least 10,000 steps daily for optimal health benefits
            </Text>
            <Text style={styles.tipText}>
              🚶‍♀️ Take short walks throughout the day to stay active
            </Text>
            <Text style={styles.tipText}>
              💧 Stay hydrated and maintain a balanced diet
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  headerTop: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatarContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#3B82F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  headerInfo: {
    flex: 1,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  joinDate: {
    fontSize: 14,
    color: '#6B7280',
  },
  editButton: {
    backgroundColor: '#3B82F6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    marginBottom: 8,
  },
  editButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
    marginLeft: 8,
  },
  cancelButton: {
    alignItems: 'center',
    paddingVertical: 8,
  },
  cancelButtonText: {
    color: '#6B7280',
    fontWeight: '500',
  },
  healthContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 12,
  },
  healthGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  healthCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  healthLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 4,
  },
  healthValue: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  healthCategory: {
    fontSize: 12,
    fontWeight: '500',
  },
  personalContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  personalCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  fieldRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  fieldLabel: {
    fontSize: 16,
    color: '#374151',
    fontWeight: '500',
  },
  fieldValue: {
    fontSize: 16,
    color: '#1F2937',
  },
  fieldInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  fieldInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 16,
    minWidth: 80,
    textAlign: 'right',
  },
  fieldUnit: {
    marginLeft: 8,
    fontSize: 14,
    color: '#6B7280',
  },
  achievementsContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  achievementsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  achievementCard: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    width: '47%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  achievementValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1F2937',
    marginTop: 8,
    marginBottom: 4,
  },
  achievementLabel: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
  },
  appInfoContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  appInfoCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  appInfoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  appInfoLabel: {
    fontSize: 16,
    color: '#374151',
    fontWeight: '500',
  },
  appInfoValue: {
    fontSize: 16,
    color: '#1F2937',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
    marginRight: 8,
  },
  tipsContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  tipsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  tipText: {
    fontSize: 14,
    color: '#374151',
    lineHeight: 20,
    marginBottom: 12,
  },
});