import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFitnessData } from '@/hooks/useFitnessData';
import { Target, CreditCard as Edit3, Save, Trophy, TrendingUp } from 'lucide-react-native';
import { ProgressCircle } from '@/components/ProgressCircle';

export default function Goals() {
  const { userProfile, updateUserProfile, currentActivity } = useFitnessData();
  const [isEditing, setIsEditing] = useState(false);
  const [editedProfile, setEditedProfile] = useState(userProfile);

  const handleSave = async () => {
    try {
      await updateUserProfile(editedProfile);
      setIsEditing(false);
      Alert.alert('Success', 'Goals updated successfully!');
    } catch (error) {
      Alert.alert('Error', 'Failed to update goals. Please try again.');
    }
  };

  const handleCancel = () => {
    setEditedProfile(userProfile);
    setIsEditing(false);
  };

  const goals = [
    {
      title: 'Daily Steps',
      current: currentActivity.steps,
      target: isEditing ? editedProfile.dailyStepGoal : userProfile.dailyStepGoal,
      unit: 'steps',
      color: '#3B82F6',
      key: 'dailyStepGoal',
    },
    {
      title: 'Daily Distance',
      current: currentActivity.distance,
      target: isEditing ? editedProfile.dailyDistanceGoal : userProfile.dailyDistanceGoal,
      unit: 'm',
      color: '#10B981',
      key: 'dailyDistanceGoal',
      formatDisplay: (value: number) => value >= 1000 ? `${(value / 1000).toFixed(1)} km` : `${value} m`,
    },
    {
      title: 'Daily Calories',
      current: currentActivity.calories,
      target: isEditing ? editedProfile.dailyCalorieGoal : userProfile.dailyCalorieGoal,
      unit: 'kcal',
      color: '#F59E0B',
      key: 'dailyCalorieGoal',
    },
  ];

  const getAchievementLevel = (progress: number) => {
    if (progress >= 1) return { level: 'Champion', emoji: '🏆', color: '#EAB308' };
    if (progress >= 0.8) return { level: 'Almost There', emoji: '🎯', color: '#3B82F6' };
    if (progress >= 0.5) return { level: 'Keep Going', emoji: '💪', color: '#10B981' };
    return { level: 'Getting Started', emoji: '🌟', color: '#6B7280' };
  };

  const overallProgress = goals.reduce((sum, goal) => sum + Math.min(goal.current / goal.target, 1), 0) / goals.length;
  const achievement = getAchievementLevel(overallProgress);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Fitness Goals</Text>
          <Text style={styles.subtitle}>Set and track your daily targets</Text>
          
          <TouchableOpacity
            style={styles.editButton}
            onPress={isEditing ? handleSave : () => setIsEditing(true)}
          >
            {isEditing ? (
              <Save size={20} color="#FFFFFF" />
            ) : (
              <Edit3 size={20} color="#FFFFFF" />
            )}
            <Text style={styles.editButtonText}>
              {isEditing ? 'Save' : 'Edit Goals'}
            </Text>
          </TouchableOpacity>
          
          {isEditing && (
            <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Overall Progress */}
        <View style={styles.overallProgressContainer}>
          <Text style={styles.overallProgressTitle}>Today's Progress</Text>
          <View style={styles.overallProgressContent}>
            <ProgressCircle
              progress={overallProgress}
              size={120}
              strokeWidth={10}
              color={achievement.color}
            >
              <Text style={styles.overallProgressText}>
                {Math.round(overallProgress * 100)}%
              </Text>
              <Text style={styles.overallProgressSubtext}>Complete</Text>
            </ProgressCircle>
            <View style={styles.achievementBadge}>
              <Text style={styles.achievementEmoji}>{achievement.emoji}</Text>
              <Text style={styles.achievementLevel}>{achievement.level}</Text>
            </View>
          </View>
        </View>

        {/* Goals List */}
        <View style={styles.goalsContainer}>
          {goals.map((goal, index) => {
            const progress = Math.min(goal.current / goal.target, 1);
            const isCompleted = progress >= 1;
            
            return (
              <View key={goal.key} style={styles.goalCard}>
                <View style={styles.goalHeader}>
                  <Text style={styles.goalTitle}>{goal.title}</Text>
                  {isCompleted && (
                    <View style={styles.completedBadge}>
                      <Trophy size={16} color="#EAB308" />
                      <Text style={styles.completedText}>Completed</Text>
                    </View>
                  )}
                </View>
                
                <View style={styles.goalContent}>
                  <ProgressCircle
                    progress={progress}
                    size={80}
                    strokeWidth={6}
                    color={goal.color}
                  >
                    <Text style={[styles.goalProgress, { color: goal.color }]}>
                      {Math.round(progress * 100)}%
                    </Text>
                  </ProgressCircle>
                  
                  <View style={styles.goalDetails}>
                    <Text style={styles.goalCurrent}>
                      {goal.formatDisplay ? goal.formatDisplay(goal.current) : goal.current.toLocaleString()}
                    </Text>
                    <Text style={styles.goalTarget}>
                      of {goal.formatDisplay ? goal.formatDisplay(goal.target) : goal.target.toLocaleString()} {goal.unit}
                    </Text>
                    
                    {isEditing && (
                      <View style={styles.goalInput}>
                        <Text style={styles.inputLabel}>Target:</Text>
                        <TextInput
                          style={styles.textInput}
                          value={editedProfile[goal.key as keyof typeof editedProfile].toString()}
                          onChangeText={(text) => {
                            const value = parseInt(text) || 0;
                            setEditedProfile(prev => ({
                              ...prev,
                              [goal.key]: value,
                            }));
                          }}
                          keyboardType="numeric"
                          placeholder={`Enter ${goal.title.toLowerCase()}`}
                        />
                      </View>
                    )}
                  </View>
                </View>
                
                <View style={styles.goalProgress}>
                  <View style={styles.progressBar}>
                    <View 
                      style={[
                        styles.progressFill, 
                        { width: `${Math.min(progress * 100, 100)}%`, backgroundColor: goal.color }
                      ]} 
                    />
                  </View>
                  <Text style={styles.progressText}>
                    {goal.current >= goal.target ? 
                      `+${(goal.current - goal.target).toLocaleString()} bonus!` : 
                      `${(goal.target - goal.current).toLocaleString()} to go`
                    }
                  </Text>
                </View>
              </View>
            );
          })}
        </View>

        {/* Weekly Trends */}
        <View style={styles.trendsContainer}>
          <Text style={styles.trendsTitle}>This Week's Trends</Text>
          <View style={styles.trendCard}>
            <View style={styles.trendItem}>
              <TrendingUp size={20} color="#10B981" />
              <Text style={styles.trendText}>
                Steps increased by 15% this week
              </Text>
            </View>
            <View style={styles.trendItem}>
              <Target size={20} color="#3B82F6" />
              <Text style={styles.trendText}>
                Goals achieved 4 out of 7 days
              </Text>
            </View>
          </View>
        </View>

        {/* Motivational Section */}
        <View style={styles.motivationContainer}>
          <Text style={styles.motivationTitle}>
            {overallProgress >= 0.8 ? '🔥 You\'re on fire!' : '💪 Keep pushing!'}
          </Text>
          <Text style={styles.motivationText}>
            {overallProgress >= 0.8 
              ? 'Amazing work! You\'re crushing your fitness goals today!'
              : 'Every step counts! Stay consistent and you\'ll reach your goals.'}
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
    marginBottom: 16,
  },
  editButton: {
    backgroundColor: '#3B82F6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    marginBottom: 8,
  },
  editButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
    marginLeft: 8,
  },
  cancelButton: {
    alignItems: 'center',
    paddingVertical: 8,
  },
  cancelButtonText: {
    color: '#6B7280',
    fontWeight: '500',
  },
  overallProgressContainer: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  overallProgressTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 16,
    textAlign: 'center',
  },
  overallProgressContent: {
    alignItems: 'center',
  },
  overallProgressText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F2937',
  },
  overallProgressSubtext: {
    fontSize: 12,
    color: '#6B7280',
  },
  achievementBadge: {
    alignItems: 'center',
    marginTop: 16,
  },
  achievementEmoji: {
    fontSize: 32,
    marginBottom: 4,
  },
  achievementLevel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1F2937',
  },
  goalsContainer: {
    paddingHorizontal: 20,
  },
  goalCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  goalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  goalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
  },
  completedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  completedText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#92400E',
    marginLeft: 4,
  },
  goalContent: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  goalProgress: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  goalDetails: {
    flex: 1,
    marginLeft: 20,
  },
  goalCurrent: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F2937',
  },
  goalTarget: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 2,
  },
  goalInput: {
    marginTop: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  inputLabel: {
    fontSize: 14,
    color: '#374151',
    marginRight: 8,
  },
  textInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 14,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#E5E7EB',
    borderRadius: 4,
    overflow: 'hidden',
    flex: 1,
    marginRight: 12,
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressText: {
    fontSize: 12,
    color: '#6B7280',
    fontWeight: '500',
  },
  trendsContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  trendsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 12,
  },
  trendCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  trendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  trendText: {
    fontSize: 14,
    color: '#374151',
    marginLeft: 12,
  },
  motivationContainer: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  motivationTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 8,
    textAlign: 'center',
  },
  motivationText: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
  },
});