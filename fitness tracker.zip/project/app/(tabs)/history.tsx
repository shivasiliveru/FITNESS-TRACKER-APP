import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { VictoryChart, VictoryLine, VictoryArea, VictoryAxis, VictoryTheme, VictoryBar } from 'victory-native';
import { useFitnessData } from '@/hooks/useFitnessData';
import { Calendar, TrendingUp, ChartBar as BarChart3 } from 'lucide-react-native';

type ChartType = 'steps' | 'distance' | 'calories';
type TimeRange = '7d' | '30d';

export default function History() {
  const { historicalData, currentActivity } = useFitnessData();
  const [selectedChart, setSelectedChart] = useState<ChartType>('steps');
  const [timeRange, setTimeRange] = useState<TimeRange>('7d');

  // Combine current activity with historical data
  const allData = [
    ...historicalData,
    currentActivity
  ].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Filter data based on time range
  const getFilteredData = () => {
    const days = timeRange === '7d' ? 7 : 30;
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - days);

    return allData.filter(item => {
      const itemDate = new Date(item.date);
      return itemDate >= startDate && itemDate <= endDate;
    }).slice(-days);
  };

  const filteredData = getFilteredData();

  // Prepare chart data
  const getChartData = () => {
    return filteredData.map((item, index) => ({
      x: index + 1,
      y: selectedChart === 'steps' ? item.steps : 
         selectedChart === 'distance' ? item.distance / 1000 : // Convert to km
         item.calories,
      label: new Date(item.date).toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
      }),
    }));
  };

  const chartData = getChartData();

  // Calculate statistics
  const calculateStats = () => {
    if (filteredData.length === 0) return null;

    const total = filteredData.reduce((sum, item) => {
      return sum + (selectedChart === 'steps' ? item.steps : 
                   selectedChart === 'distance' ? item.distance : 
                   item.calories);
    }, 0);

    const average = total / filteredData.length;
    const max = Math.max(...filteredData.map(item => 
      selectedChart === 'steps' ? item.steps : 
      selectedChart === 'distance' ? item.distance : 
      item.calories
    ));

    return { total, average, max };
  };

  const stats = calculateStats();

  const getChartConfig = () => {
    switch (selectedChart) {
      case 'steps':
        return {
          title: 'Daily Steps',
          color: '#3B82F6',
          unit: 'steps',
          formatValue: (value: number) => value.toLocaleString(),
        };
      case 'distance':
        return {
          title: 'Daily Distance',
          color: '#10B981',
          unit: 'km',
          formatValue: (value: number) => (value / 1000).toFixed(1),
        };
      case 'calories':
        return {
          title: 'Daily Calories',
          color: '#F59E0B',
          unit: 'kcal',
          formatValue: (value: number) => value.toString(),
        };
    }
  };

  const config = getChartConfig();

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Activity History</Text>
          <Text style={styles.subtitle}>Track your progress over time</Text>
        </View>

        {/* Time Range Selector */}
        <View style={styles.timeRangeContainer}>
          <TouchableOpacity
            style={[
              styles.timeRangeButton,
              timeRange === '7d' && styles.timeRangeButtonActive,
            ]}
            onPress={() => setTimeRange('7d')}
          >
            <Text style={[
              styles.timeRangeText,
              timeRange === '7d' && styles.timeRangeTextActive,
            ]}>7 Days</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.timeRangeButton,
              timeRange === '30d' && styles.timeRangeButtonActive,
            ]}
            onPress={() => setTimeRange('30d')}
          >
            <Text style={[
              styles.timeRangeText,
              timeRange === '30d' && styles.timeRangeTextActive,
            ]}>30 Days</Text>
          </TouchableOpacity>
        </View>

        {/* Chart Type Selector */}
        <View style={styles.chartTypeContainer}>
          {(['steps', 'distance', 'calories'] as ChartType[]).map((type) => (
            <TouchableOpacity
              key={type}
              style={[
                styles.chartTypeButton,
                selectedChart === type && styles.chartTypeButtonActive,
              ]}
              onPress={() => setSelectedChart(type)}
            >
              <Text style={[
                styles.chartTypeText,
                selectedChart === type && styles.chartTypeTextActive,
              ]}>
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Statistics Cards */}
        {stats && (
          <View style={styles.statsContainer}>
            <View style={styles.statCard}>
              <Text style={styles.statLabel}>Total</Text>
              <Text style={[styles.statValue, { color: config.color }]}>
                {config.formatValue(stats.total)}
              </Text>
              <Text style={styles.statUnit}>{config.unit}</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statLabel}>Average</Text>
              <Text style={[styles.statValue, { color: config.color }]}>
                {config.formatValue(stats.average)}
              </Text>
              <Text style={styles.statUnit}>{config.unit}</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statLabel}>Best Day</Text>
              <Text style={[styles.statValue, { color: config.color }]}>
                {config.formatValue(stats.max)}
              </Text>
              <Text style={styles.statUnit}>{config.unit}</Text>
            </View>
          </View>
        )}

        {/* Chart */}
        <View style={styles.chartContainer}>
          <Text style={styles.chartTitle}>{config.title}</Text>
          {chartData.length > 0 ? (
            <VictoryChart
              theme={VictoryTheme.material}
              height={250}
              padding={{ left: 60, top: 20, right: 40, bottom: 60 }}
            >
              <VictoryAxis
                dependentAxis
                tickFormat={(value) => config.formatValue(value)}
                style={{
                  tickLabels: { fontSize: 12, fill: '#6B7280' },
                  grid: { stroke: '#E5E7EB', strokeWidth: 0.5 },
                }}
              />
              <VictoryAxis
                tickFormat={() => ''}
                style={{
                  tickLabels: { fontSize: 12, fill: '#6B7280' },
                  axis: { stroke: '#E5E7EB' },
                }}
              />
              <VictoryArea
                data={chartData}
                style={{
                  data: { 
                    fill: `${config.color}20`, 
                    stroke: config.color, 
                    strokeWidth: 2 
                  },
                }}
                animate={{
                  duration: 1000,
                  onLoad: { duration: 500 }
                }}
              />
              <VictoryLine
                data={chartData}
                style={{
                  data: { stroke: config.color, strokeWidth: 3 },
                }}
                animate={{
                  duration: 1000,
                  onLoad: { duration: 500 }
                }}
              />
            </VictoryChart>
          ) : (
            <View style={styles.noDataContainer}>
              <BarChart3 size={48} color="#9CA3AF" />
              <Text style={styles.noDataText}>No data available</Text>
              <Text style={styles.noDataSubtext}>Start tracking to see your progress</Text>
            </View>
          )}
        </View>

        {/* Weekly Comparison */}
        {timeRange === '30d' && chartData.length >= 14 && (
          <View style={styles.comparisonContainer}>
            <Text style={styles.comparisonTitle}>Weekly Comparison</Text>
            <VictoryChart
              theme={VictoryTheme.material}
              height={200}
              padding={{ left: 60, top: 20, right: 40, bottom: 60 }}
            >
              <VictoryAxis dependentAxis />
              <VictoryBar
                data={[
                  { x: 'Week 1', y: chartData.slice(0, 7).reduce((sum, item) => sum + item.y, 0) / 7 },
                  { x: 'Week 2', y: chartData.slice(7, 14).reduce((sum, item) => sum + item.y, 0) / 7 },
                  { x: 'Week 3', y: chartData.slice(14, 21).reduce((sum, item) => sum + item.y, 0) / 7 },
                  { x: 'Week 4', y: chartData.slice(21, 28).reduce((sum, item) => sum + item.y, 0) / 7 },
                ]}
                style={{
                  data: { fill: config.color },
                }}
                animate={{
                  duration: 1000,
                  onLoad: { duration: 500 }
                }}
              />
            </VictoryChart>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
  },
  timeRangeContainer: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginBottom: 16,
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    padding: 4,
  },
  timeRangeButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  timeRangeButtonActive: {
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  timeRangeText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  timeRangeTextActive: {
    color: '#1F2937',
  },
  chartTypeContainer: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginBottom: 20,
    gap: 8,
  },
  chartTypeButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  chartTypeButtonActive: {
    backgroundColor: '#3B82F6',
    borderColor: '#3B82F6',
  },
  chartTypeText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  chartTypeTextActive: {
    color: '#FFFFFF',
  },
  statsContainer: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginBottom: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  statLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 4,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  statUnit: {
    fontSize: 10,
    color: '#9CA3AF',
  },
  chartContainer: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 16,
    textAlign: 'center',
  },
  noDataContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  noDataText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#6B7280',
    marginTop: 12,
  },
  noDataSubtext: {
    fontSize: 14,
    color: '#9CA3AF',
    marginTop: 4,
  },
  comparisonContainer: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  comparisonTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 16,
    textAlign: 'center',
  },
});