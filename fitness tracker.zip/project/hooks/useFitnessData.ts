import { useState, useEffect } from 'react';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Pedometer } from 'expo-sensors';
import { DailyActivity, UserProfile } from '@/types/fitness';

const STORAGE_KEYS = {
  DAILY_ACTIVITY: 'daily_activity',
  USER_PROFILE: 'user_profile',
  HISTORICAL_DATA: 'historical_data',
};

const DEFAULT_PROFILE: UserProfile = {
  name: 'Fitness Enthusiast',
  age: 30,
  weight: 70,
  height: 170,
  dailyStepGoal: 10000,
  dailyDistanceGoal: 8000,
  dailyCalorieGoal: 2000,
};

export function useFitnessData() {
  const [currentActivity, setCurrentActivity] = useState<DailyActivity>({
    date: new Date().toISOString().split('T')[0],
    steps: 0,
    distance: 0,
    calories: 0,
    activeMinutes: 0,
  });
  
  const [userProfile, setUserProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [historicalData, setHistoricalData] = useState<DailyActivity[]>([]);
  const [isTracking, setIsTracking] = useState(false);
  const [subscription, setSubscription] = useState<any>(null);

  // Calculate distance from steps (average step length: 0.78m)
  const calculateDistance = (steps: number): number => {
    return Math.round(steps * 0.78);
  };

  // Calculate calories burned based on steps and user weight
  const calculateCalories = (steps: number, weight: number): number => {
    // Approximate: 0.04 calories per step per kg of body weight
    return Math.round(steps * 0.04 * weight);
  };

  // Simulate step counting for web platform
  const simulateSteps = () => {
    if (Platform.OS === 'web') {
      const interval = setInterval(() => {
        setCurrentActivity(prev => {
          const newSteps = prev.steps + Math.floor(Math.random() * 3) + 1;
          const newDistance = calculateDistance(newSteps);
          const newCalories = calculateCalories(newSteps, userProfile.weight);
          
          return {
            ...prev,
            steps: newSteps,
            distance: newDistance,
            calories: newCalories,
            activeMinutes: Math.floor(newSteps / 100), // Rough estimation
          };
        });
      }, 2000);
      
      return () => clearInterval(interval);
    }
  };

  // Initialize pedometer for native platforms
  const initializePedometer = async () => {
    if (Platform.OS !== 'web') {
      try {
        const isAvailable = await Pedometer.isAvailableAsync();
        if (isAvailable) {
          const end = new Date();
          const start = new Date();
          start.setHours(0, 0, 0, 0);
          
          // Get today's steps
          const pastStepCountResult = await Pedometer.getStepCountAsync(start, end);
          
          setCurrentActivity(prev => ({
            ...prev,
            steps: pastStepCountResult.steps,
            distance: calculateDistance(pastStepCountResult.steps),
            calories: calculateCalories(pastStepCountResult.steps, userProfile.weight),
          }));
          
          // Subscribe to live updates
          const sub = Pedometer.watchStepCount(result => {
            setCurrentActivity(prev => {
              const totalSteps = prev.steps + result.steps;
              return {
                ...prev,
                steps: totalSteps,
                distance: calculateDistance(totalSteps),
                calories: calculateCalories(totalSteps, userProfile.weight),
              };
            });
          });
          
          setSubscription(sub);
          setIsTracking(true);
        }
      } catch (error) {
        console.error('Error initializing pedometer:', error);
        // Fall back to simulation on error
        const cleanup = simulateSteps();
        setIsTracking(true);
        return cleanup;
      }
    } else {
      // Use simulation for web
      const cleanup = simulateSteps();
      setIsTracking(true);
      return cleanup;
    }
  };

  // Load stored data
  const loadStoredData = async () => {
    try {
      const [storedProfile, storedHistorical] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.USER_PROFILE),
        AsyncStorage.getItem(STORAGE_KEYS.HISTORICAL_DATA),
      ]);
      
      if (storedProfile) {
        setUserProfile(JSON.parse(storedProfile));
      }
      
      if (storedHistorical) {
        setHistoricalData(JSON.parse(storedHistorical));
      }
    } catch (error) {
      console.error('Error loading stored data:', error);
    }
  };

  // Save daily activity
  const saveDailyActivity = async (activity: DailyActivity) => {
    try {
      const updated = [...historicalData];
      const existingIndex = updated.findIndex(item => item.date === activity.date);
      
      if (existingIndex >= 0) {
        updated[existingIndex] = activity;
      } else {
        updated.push(activity);
      }
      
      // Keep only last 30 days
      const sortedData = updated
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 30);
      
      setHistoricalData(sortedData);
      await AsyncStorage.setItem(STORAGE_KEYS.HISTORICAL_DATA, JSON.stringify(sortedData));
    } catch (error) {
      console.error('Error saving daily activity:', error);
    }
  };

  // Update user profile
  const updateUserProfile = async (profile: UserProfile) => {
    try {
      setUserProfile(profile);
      await AsyncStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
    } catch (error) {
      console.error('Error updating user profile:', error);
    }
  };

  // Initialize on mount
  useEffect(() => {
    loadStoredData();
    initializePedometer();
    
    return () => {
      if (subscription) {
        subscription.remove();
      }
    };
  }, []);

  // Save current activity at end of day
  useEffect(() => {
    const saveInterval = setInterval(() => {
      if (currentActivity.steps > 0) {
        saveDailyActivity(currentActivity);
      }
    }, 60000); // Save every minute
    
    return () => clearInterval(saveInterval);
  }, [currentActivity]);

  return {
    currentActivity,
    userProfile,
    historicalData,
    isTracking,
    updateUserProfile,
    saveDailyActivity,
  };
}