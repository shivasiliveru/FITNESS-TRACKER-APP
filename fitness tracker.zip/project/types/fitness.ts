export interface DailyActivity {
  date: string;
  steps: number;
  distance: number; // in meters
  calories: number;
  activeMinutes: number;
}

export interface UserProfile {
  name: string;
  age: number;
  weight: number; // in kg
  height: number; // in cm
  dailyStepGoal: number;
  dailyDistanceGoal: number; // in meters
  dailyCalorieGoal: number;
}

export interface WeeklyStats {
  totalSteps: number;
  totalDistance: number;
  totalCalories: number;
  averageSteps: number;
  daysActive: number;
}