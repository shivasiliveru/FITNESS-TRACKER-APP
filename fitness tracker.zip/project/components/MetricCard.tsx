import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ProgressCircle } from './ProgressCircle';

interface MetricCardProps {
  title: string;
  value: string;
  unit: string;
  progress: number;
  goal: string;
  colors: string[];
  icon: React.ReactNode;
}

export function MetricCard({
  title,
  value,
  unit,
  progress,
  goal,
  colors,
  icon,
}: MetricCardProps) {
  return (
    <LinearGradient colors={colors} style={styles.card}>
      <View style={styles.header}>
        <View style={styles.iconContainer}>
          {icon}
        </View>
        <Text style={styles.title}>{title}</Text>
      </View>
      
      <View style={styles.content}>
        <ProgressCircle
          progress={progress}
          size={120}
          strokeWidth={8}
          color="#FFFFFF"
          backgroundColor="rgba(255, 255, 255, 0.3)"
        >
          <Text style={styles.value}>{value}</Text>
          <Text style={styles.unit}>{unit}</Text>
        </ProgressCircle>
        
        <Text style={styles.goal}>Goal: {goal}</Text>
        <Text style={styles.percentage}>
          {Math.round(progress * 100)}% Complete
        </Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 20,
    padding: 20,
    margin: 8,
    minHeight: 220,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  iconContainer: {
    marginRight: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  content: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
  },
  value: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
  },
  unit: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.8)',
    textAlign: 'center',
  },
  goal: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.9)',
    marginTop: 12,
    textAlign: 'center',
  },
  percentage: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.7)',
    marginTop: 4,
    textAlign: 'center',
  },
});